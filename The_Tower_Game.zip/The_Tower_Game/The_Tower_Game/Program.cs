﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace The_Tower_Game
{
    class Program
    {
        static void Main(string[] args)
        {
            Text test = new Text();
            test.intro();
            test.User_Name = Console.ReadLine();
            test.runes();





            Console.ReadKey();
        }
    }
}
