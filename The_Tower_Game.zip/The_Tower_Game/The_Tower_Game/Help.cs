﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace The_Tower_Game
{
    class Help
    {
        public void Error()
        {
            Console.ForegroundColor = ConsoleColor.Red;
            Console.WriteLine("Error001\nVar vitlaust valið i class(runes) menu");
        }

      
    }
}
